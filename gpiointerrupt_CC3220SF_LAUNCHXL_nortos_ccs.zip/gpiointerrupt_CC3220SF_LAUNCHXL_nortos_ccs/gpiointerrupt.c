/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#define DOT_DURATION         500000  // 500 ms
#define DASH_DURATION        1500000 // 1500 ms
#define INTER_CHARACTER_GAP  1500000 // 3 * 500 ms
#define INTER_WORD_GAP       3500000 // 7 * 500 ms

typedef enum {
    STATE_SOS,
    STATE_OK
} MessageState;

typedef enum {
    SOS_DOT1,
    SOS_GAP1,
    SOS_DOT2,
    SOS_GAP2,
    SOS_DOT3,
    SOS_GAP3,
    SOS_DASH1,
    SOS_GAP4,
    SOS_DASH2,
    SOS_GAP5,
    SOS_DASH3,
    SOS_GAP6,
    SOS_DOT4,
    SOS_GAP7,
    SOS_DOT5,
    SOS_GAP8,
    SOS_DOT6,
    SOS_WORD_GAP,
    OK_DOT1,
    OK_GAP1,
    OK_DOT2,
    OK_GAP2,
    OK_DOT3,
    OK_GAP3,
    OK_DASH,
    OK_GAP4,
    OK_WORD_GAP
} MorseState;

static volatile MessageState messageState = STATE_SOS;
static volatile MorseState morseState = SOS_DOT1;
static volatile bool isButtonPressed = false;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    static uint32_t elapsedTime = 0;

        if (isButtonPressed) {
            isButtonPressed = false;
            messageState = (messageState == STATE_SOS) ? STATE_OK : STATE_SOS;
            morseState = (messageState == STATE_SOS) ? SOS_DOT1 : OK_DOT1;
        }

        switch (morseState) {
            case SOS_DOT1:
            case SOS_DOT2:
            case SOS_DOT3:
            case SOS_DOT4:
            case SOS_DOT5:
            case SOS_DOT6:
            case OK_DOT1:
            case OK_DOT2:
            case OK_DOT3:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                elapsedTime += DOT_DURATION;
                morseState++;
                break;

            case SOS_DASH1:
            case SOS_DASH2:
            case SOS_DASH3:
            case OK_DASH:
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                elapsedTime += DASH_DURATION;
                morseState++;
                break;

            case SOS_GAP1:
            case SOS_GAP2:
            case SOS_GAP3:
            case SOS_GAP4:
            case SOS_GAP5:
            case SOS_GAP6:
            case SOS_GAP7:
            case SOS_GAP8:
            case OK_GAP1:
            case OK_GAP2:
            case OK_GAP3:
            case OK_GAP4:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                elapsedTime += INTER_CHARACTER_GAP;
                morseState++;
                break;

            case SOS_WORD_GAP:
            case OK_WORD_GAP:
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                elapsedTime += INTER_WORD_GAP;
                morseState = (messageState == STATE_SOS) ? SOS_DOT1 : OK_DOT1;
                break;

            default:
                break;
        }
}

void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 1000000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    // Toggling LED
    isButtonPressed = true;
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    // Toggling LED
    isButtonPressed = true;
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
//    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    initTimer();

    return (NULL);
}
